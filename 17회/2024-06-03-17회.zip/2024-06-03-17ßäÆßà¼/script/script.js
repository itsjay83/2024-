jQuery(document).ready(() => {
	$(".main li").mouseover(function () {
		$(this).find(".sub").stop().slideDown();
	});

	$(".main li").mouseout(function () {
		$(this).find(".sub").stop().slideUp();
	});

	$(".notice li").click(() => {
		$(".popup").show();
	});

	$(".close").click(() => {
		$(".popup").hide();
	});
});
